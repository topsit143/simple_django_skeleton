# simple_django_skeleton
simple_django_skeleton of new project
